<?php
class WP_Travel_FW_Field_Number extends WP_Travel_FW_Field_Text {
	protected $field_type = 'number';
}
