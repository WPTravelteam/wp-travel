<?php
class WP_Travel_FW_Field_Hidden extends WP_Travel_FW_Field_Text {
	protected $field_type = 'hidden';
}
